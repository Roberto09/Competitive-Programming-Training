/*
	Problem: Luca and Stock
	Difficulty: medium
	Topics: Segment tree, math

	Solution: Implement a segment tree but use logarithms to avoid multiplying (avoid loss of precision).
			  Exponentiate the answer withing the segment before printing.
*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(decltype((cont).begin()) it = (cont).begin(); it != (cont).end(); it++)
#define pb push_back

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;

#define maxN 100000
#define arbitraryConstant 69.314718055994530941723212145818

int N, Q;
double t[2*maxN];

int main() {
	while (scanf("%d", &N) != EOF) {
		FOR(i, 0, N) {
			scanf("%lf", &t[N + i]);
			t[N + i] = log(t[N + i]);
		}
		for (int i = N - 1; i; i--) t[i] = t[i << 1] + t[i << 1 | 1];
		scanf("%d", &Q);
		int type, x, l, r;
		double p;
		FOR(i, 0, Q) {
			scanf("%d", &type);
			if (type == 2) {
				scanf("%d %d", &l, &r);
				double ans = 0;
				for (l += N - 1, r += N; l < r; l >>= 1, r >>= 1) {
					if (l & 1) ans += t[l++];
					if (r & 1) ans += t[--r];
				}
				if(ans<arbitraryConstant) printf("%.9f\n", exp(ans));
				else printf("INFINITE!\n");
			}
			else {
				scanf("%d %lf", &x, &p);
				t[x += N - 1] = log(p);
				while (x>>=1) t[x] = t[x << 1] + t[x << 1 | 1];
			}
		}
	}
	return 0;
}
