/*
	Problem: Basic Encryption
	Author: Diego Yepiz
	Difficulty: Very easy
	Topic: Input

	Solution: You are given the encoded string and each alphabetical character is cyclically increased S characters.
			  In order to undo that you have to take away S from every alphabetical character (consider that A-1 = Z).

			  Time complexity: O(sum(l[i].length())), time complexity is the sum of the lengths of all lines
*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(decltype((cont).begin()) it = (cont).begin(); it != (cont).end(); it++)
#define pb push_back

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;

int N, S;
string line;

int main() {
	cin >> N >> S;
	getline(cin, line);
    FOR(i,0,N) {
	    getline(cin, line);
		FOR(i, 0, line.length()) {
			if (line[i] >= 'a' && line[i] <= 'z') {
				line[i] = (line[i] - 'a' - S%26 + 26) % 26 + 'a';
			}
			if (line[i] >= 'A' && line[i] <= 'Z') {
				line[i] = (line[i] - 'A' - S%26 + 26) % 26 + 'A';
			}
		}
		cout << line << endl;
	}
	return 0;
}
