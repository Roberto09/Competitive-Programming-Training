/*
	Problem: Perfect Polygon
	Author: Diego Yepiz
	Difficulty: medium-easy
	Topics: Geometry

	Solution: We first rotate the polygon by the specified angle, 
			  In order to do that we can convert degrees to radians 
			  and then apply sin and cosine functions (which regularly work with radians).

			  Then we have to imagine like the polygon is already contained within a box.
			  Since the final box is a rectandle that touches 0,0 and W,H, 
			  We have to translate that box to the 0,0 and then scale it to be W,H.

			  O(N)
*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(decltype((cont).begin()) it = (cont).begin(); it != (cont).end(); it++)
#define pb push_back

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;

#define maxN 100000
#define PI 3.14159265358979

struct Data {
	double x, y;
};

Data p[maxN];

int main() {
	int A, W, H, N;
	while (scanf("%d %d %d %d", &A, &W, &H, &N) != EOF) {
		FOR(i, 0, N) scanf("%lf %lf", &p[i].x, &p[i].y);
		double rad = A*PI / 180.;
		// Apply rotation
		FOR(i, 0, N) {
			double ty = p[i].y*cos(rad) + p[i].x*sin(rad);
			p[i].x = - p[i].y*sin(rad) + p[i].x*cos(rad);
			p[i].y = ty;
		}
		// Get bounding box of current polygon, its opposite corners are located in (loX, loY) and (hiX, hiY)
		double loX = INF, hiX = -INF, loY = INF, hiY = -INF;
		FOR(i, 0, N) {
			loX = min(loX, p[i].x);
			hiX = max(hiX, p[i].x);
			loY = min(loY, p[i].y);
			hiY = max(hiY, p[i].y);
		}
		// Translate the box (every point inside of it) and apply the scale
		double scaleX = W / (hiX - loX), scaleY = H / (hiY - loY);
		FOR(i, 0, N) {
			p[i].x = (p[i].x - loX)*scaleX;
			p[i].y = (p[i].y - loY)*scaleY;
		}
		FOR(i, 0, N) printf("%.9f %.9f\n", p[i].x, p[i].y);
	}
	return 0;
}
