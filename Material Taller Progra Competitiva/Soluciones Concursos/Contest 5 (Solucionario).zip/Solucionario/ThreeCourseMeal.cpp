/*
	Problem: Three-course meal
	Author: Diego Yepiz
	Difficulty: Hard
	Topics: Greedy, Sortings, Data structures

	Solution: First notice how given that we chose a group of friends answer is
			  given by the max(A)+max(E)+max(D) (where max implies max value amongst the group)

			  We first sort all friends based on A values, 
			  then we are going to assume that we take a friend
			  with a specific A value and that friend is part of the answer 
			  and the highest A present in the answer, we are doing that for every friend.

			  Since that friend is the highest A present in the answer, 
			  we grab all friends with A lower than that friend, we then sort those by E.
			  We do something similar where we are going to assume a specific value of E
			  is part of the answer and the highest E amongst the friends,
			  again, we do this for every friend (with A smaller than chosen A of course).

			  Every friend with value lower than A and E can be a potential answer for D.
			  Out of those we grab the friend with the K lowest D.

			  Since we first iterate over all friends to chose A values
			  and then for each of those we sort on E and then iterate on E that's N^2*logN
			  In order to get the K lowest D we can have a structure like a red-black tree or a priority queue.
			  Since we are inserting and querying for K lowest D N^2 times that's N^2*logN.

			  Time complexituy: O(N^2*logN)
*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(decltype((cont).begin()) it = (cont).begin(); it != (cont).end(); it++)
#define pb push_back

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;

#define maxN 2000

struct Data {
	unsigned int A, E, D;
	bool operator <(const Data &r) const {
		return A < r.A || A == r.A && E < r.E || A == r.A && E == r.E && D < r.D;
	}
};

int N, K;
Data m[maxN], se[maxN];

bool cmpE(const Data &l, const Data &r) {
	return l.E < r.E;
}

class CompD {
	public:
		bool operator ()(const Data &l, const Data &r) {
			return l.D < r.D;
		}
};

int main() {
	while (scanf("%d %d", &N, &K) != EOF) {
		FOR(i, 0, N) {
			scanf("%u %u %u", &m[i].A, &m[i].E, &m[i].D);
		}
		sort(m, m + N);
		unsigned int ans = 3*INF;
		FOR(i, 0, N) {
			se[i] = m[i];
			sort(se, se + i + 1, cmpE);
			priority_queue<Data, vector<Data>, CompD> q;
			FOR(j, 0, i+1) {
				q.push(se[j]);
				if (q.size() > K) q.pop();
				if (q.size()>=K) ans = min(ans, m[i].A + se[j].E + q.top().D);
			}
		}
		printf("%u\n", ans);
	}
	return 0;
}
