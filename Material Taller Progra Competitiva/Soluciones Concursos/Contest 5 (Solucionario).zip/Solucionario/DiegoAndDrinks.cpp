/*
	Problem: DiegoAndDrinks
	Author: Diego Yepiz
	Difficulty: Very easy
	Topic: Math, ad-hoc

	Solution: In the beginning everyone grabs a drink at the same time they they all "clink!" each other,
			  this means that everyone will "clink!" the same person only once in the beginning.
			  This can be represented by summation from 1 to N -> N*(N+1)/2 initial "clink!"s

			  After that whoever finishes his/her drink that person will "clink!" everyone else in the party,
			  and since noone will finish their drink in between that means there will be N "clink!"s per extra drink

			  In other words the amount of drinks at the party is the N+1 initial ones (1 per friend+Diego)
			  Plus every drink that was drank after the initial one.

			  If D drinks were drank after the initial round, then the fomula of total "clink!"s is:
			  N*(N+1)/2 + D*N = K

			  We have N and K which means we can clear for D and it should be:
			  D = (K-N*(N+1)/2)/N
			  
			  If K can't cover the initial "clink!"s or N doesn't divide the amount of "clink!"s after the initial round
			  then the answer can't be found and output should be "Too drunk to count"

			  O(1) per test case
*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(decltype((cont).begin()) it = (cont).begin(); it != (cont).end(); it++)
#define pb push_back

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;

int main() {
	int T, N, K;
	scanf("%d", &T);
	while (T--) {
		scanf("%d %d", &N, &K);
		int t = K - N*(N + 1) / 2;
		if (t < 0 || t % N != 0) printf("Too drunk to count\n");
		else {
			printf("%d\n", t / N + N + 1);
		}
	}
	return 0;
}
