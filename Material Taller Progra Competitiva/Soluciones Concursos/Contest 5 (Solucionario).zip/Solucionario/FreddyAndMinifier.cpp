/*
	Problem: Freddy And Minifier
	Author: Diego Yepiz
	Difficulty: Hard
	Topics: Greedy, Math, sorting

	Solution: Let's suppose we are going to compare only 2 guns, which one should we fire with first?
			  We'll call those 2 guns i and j.
			  
			  Suppose that you fire i first, then the cost is given by the following formula:
			  Ci*W + Cj*W*Ri

			  Now suppose that you fire j first, then we have this formula:
			  Cj*W + Ci*W*Rj

			  If it's more convenient to shoot with j first then second formula should be smaller or equal to the first one.
			  We can represent that in the following way:
			  Cj*W + Ci*W*Rj < Ci*W + Cj*W*Ri
			  We can remove W since every term has W
			  Cj + Ci*Rj < Ci + Cj*Ri
			  Move all terms with Cj and Ci to the same side
			  Cj - Cj*Ri < Ci - Ci*Rj
			  Cj*(1-Ri) < Ci*(1-Rj)
			  Move all js and is to the same side and we end up with:
			  Cj/(1-Rj) < Ci/(1-Ri)
			
			  Which means that if the last equation is true then its convenient to shoot j before i.
			  Since that equation is general and applies for every i,j pair
			  which means we can sort the guns based on that and answer should be optimal.

			  Time complexity: O(N*logN)
*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(decltype((cont).begin()) it = (cont).begin(); it != (cont).end(); it++)
#define pb push_back

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;

#define maxN 100000

struct Data {
	double c, r;
	bool operator <(const Data &o) const {
		if (r!=1.0 && o.r !=1.0)
			return c / (1. - r) < o.c / (1. - o.r);
		return o.r == 1.0;
	}
};

int N;
double W;
Data guns[maxN];

int main() {
	while (scanf("%d %lf", &N, &W) != EOF) {
		FOR(i, 0, N) {
			scanf("%lf %lf", &guns[i].c, &guns[i].r);
		}
		sort(guns, guns + N);
		double ans = 0.0;
		FOR(i, 0, N) {
			ans += guns[i].c*W;
			W *= guns[i].r;
		}
		printf("%.12f\n", ans);
	}
	return 0;
}
