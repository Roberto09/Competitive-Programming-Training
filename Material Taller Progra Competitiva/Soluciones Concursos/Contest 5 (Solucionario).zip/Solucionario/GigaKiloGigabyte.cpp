/*
	Problem: Giga-Kilo-GigaByte
	Author: Diego Yepiz
	Difficulty: medium-easy
	Topics: DP
	
	Solution: First notice how input is always multiple of 3
			  and jumps in prefixes are also in multiples of 3.
			  Which means we can divide N by 3 and pretends prefixes are applied every zero to the right.
			  Realize that for N=0 there is 1 answer.
			  We have 8 possible transitions (from kilo to yotta)
			  For every state the answer is given by the sum of transitions
			  Remember to use MODs

			  Time complexity: O(N*K), where K is the transitions, in this case 8.

			  Extra-challenge: Can you think of a way to solve this problem in O(N) even for huge number of consecutive transitions?
*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(decltype((cont).begin()) it = (cont).begin(); it != (cont).end(); it++)
#define pb push_back

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;

#define maxN 1000001
#define MOD 1000000007

ll dp[maxN];

int main() {
	int T, N;
	dp[0] = 1;
	FOR(i, 1, maxN) {
		FOR(j, 1, 9) if (i >= j) dp[i] = (dp[i] + dp[i - j]) % MOD;
	}
	scanf("%d", &T);
	while (T--) {
		scanf("%d", &N);
		printf("%lld\n", dp[N/3]);
	}
	return 0;
}
