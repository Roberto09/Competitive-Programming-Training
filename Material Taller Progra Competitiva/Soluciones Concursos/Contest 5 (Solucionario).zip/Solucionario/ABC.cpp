/*
	Problem: A+B+C
	Author: Diego Yepiz
	Difficulty: easy
	Topics: Implementation

	Solution: Implement a fraction class that can add 2 fractions.
			  Since output must be simplified also simplify the fraction before printing.

			  O(1) per test case
*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(decltype((cont).begin()) it = (cont).begin(); it != (cont).end(); it++)
#define pb push_back

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;

ll gcd(ll a, ll b) {
	if (b) return gcd(b, a%b);
	return a;
}

struct Fraction {
	ll num, den;
	void simplify() {
		ll g = gcd(num, den);
		num /= g;
		den /= g;
	}
	Fraction operator + (const Fraction &r) const {
		Fraction ret;
		ret.den = den*r.den;
		ret.num = den*r.num + num*r.den;
		ret.simplify();
		return ret;
	}
};

int main() {
	int T;
	Fraction A, B, C;
	scanf("%d", &T);
	while (T--) {
		scanf("%lld/%lld %lld/%lld %lld/%lld", &A.num, &A.den, &B.num, &B.den, &C.num, &C.den);
		Fraction sum = A + B + C;
		printf("%lld/%lld\n", sum.num, sum.den);
	}
	return 0;
}
