/*
	Problem: Minimum Played Times
	Author: Diego Yepiz
	Difficulty: Easy
	Topics: Math, ad-hoc

	Solution: Realize that input is not cieled, rounded nor truncated which means that there are no extra decimals in the input.
			  In other words, the minimum amount of played times must be divisible by 2 and 5 and no other primes.
			  Since input is maximum 4 digits we can multiply times 10,000 to get a numerator
			  and then we have a fraction in the format P/10,000.
			  Simplify the fraction and output the denominator.

			  O(1) per test case
*/
#include <algorithm>
#include <bitset>
#include <cmath>
#include <cstdio>
#include <cstring>
#include <deque>
#include <functional>
#include <iomanip>
#include <iostream>
#include <queue>
#include <map>
#include <numeric>
#include <set>
#include <sstream>
#include <stack>
#include <utility>
#include <vector>

#define INF 1000000000
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define FORC(cont, it) for(decltype((cont).begin()) it = (cont).begin(); it != (cont).end(); it++)
#define pb push_back

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;
typedef vector<vi> vvi;

int gcd(int a, int b) {
	if (b) return gcd(b, a%b);
	return a;
}

int main() {
	int N;
	scanf("%d", &N);
	while (N--) {
		char s[7];
		scanf("%s", s);
		int num = 0, len = strlen(s), den = 1;
		FOR(i, 0, len) {
			if (s[i] != '.') {
				num = num * 10 + s[i] - '0';
				if(i) den *= 10;
			}
		}
		printf("%d\n", den / gcd(num, den));
	}
	return 0;
}
