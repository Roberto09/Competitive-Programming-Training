/*
	Problem: Water In Beagle Town
	Difficulty: Hard
	Topics: Flows, Maximum Bipartite Matching

	Solution: Since every Beagle takes 10 units of time to drink 1L of water, you can reduce S by 10.
			  After that generate a graph with an edge between every pair of beagle and water bowl if their distance is <=s
			  Notice that will generate a bipartite graph. 
			  We can do the maximum bipartite matching and that will determine
			  the answer of how many Beagles can drink water in time <= s.
			  Print yes if answer is N, otherwise print no.
			  
			  It can be implemented with a variation of Hopcroft-Karp (to handle c per water bowl) or a straight-forward Dinitz.
*/
#include <bits/stdc++.h>

#define PI 3.14159265358979323846
#define EPS 1e-6
#define INF 1000000000

#define _ ios_base::sync_with_stdio(0), cin.tie(0), cout.tie(0), cout.precision(15);
#define FOR(i, a, b) for(int i=int(a); i<int(b); i++)
#define RFOR(i, a, b) for(int i=int(a)-1; i>=int(b); i--)
#define FORC(it, cont) for(auto it = (cont).begin(); it != (cont).end(); it++)
#define RFORC(it, cont) for(auto it = (cont).rbegin(); it != (cont).rend(); it++)
#define pb push_back

#define sz(c) ((int)c.size())
#define print(v) cout << #v" = " << v << endl
#define printArr(arr, a, b) FOR(i, a, b) cout << #arr << "[" << i << "] = " << arr[i] << endl
#define zero(v) memset(v, 0, sizeof(v))
#define uno(v) memset(v, 1, sizeof(v))
#define unoneg(v) memset(v, -1, sizeof(v))
#define toIntA(c) (c - 'A')
#define toInta(c) (c - 'a')
#define toInt0(c) (c - '0')
#define toCharA(i) (char)(i + 'a')
#define toChara(i) (char)(i + 'A')
#define toChar0(i) (char)(i + '0')

using namespace std;

typedef long long ll;
typedef pair<int, int> ii;
typedef vector<int> vi;
typedef vector<ii> vii;

#define MAXT 5000
#define MAXN 10020
#define MOD 1000000007

int n, m, src, dest;
int dist[MAXN], q[MAXN], work[MAXN];

struct Edge {
    int to, rev;
    int f = 0, cap;

    Edge() {}
    Edge(int t, int r, int c) :
        to(t), rev(r), cap(c) {}
};
vector<Edge> graph[MAXN];

void addEdge(int s, int t, int cap) {
    graph[s].pb(Edge(t, graph[t].size(), cap));
    graph[t].pb(Edge(s, graph[s].size() - 1, 0));
}

bool dinitz_bfs() {
    memset(dist, -1, sizeof(dist));
    dist[src] = 0;
    int qt = 0;
    q[qt++] = src;
    FOR(qh, 0, qt) {
        int u = q[qh];
        FOR(j, 0, graph[u].size()) {
            Edge &e = graph[u][j];
            int v = e.to;
            if (dist[v] < 0 && e.f < e.cap) {
                dist[v] = dist[u] + 1;
                q[qt++] = v;
            }
        }
    }
    return dist[dest] >= 0;
}

int dinitz_dfs(int u, int f) {
    if (u == dest)  return f;

    for (int &i = work[u]; i < (int) graph[u].size(); i++) {
        Edge &e = graph[u][i];
        if (e.cap <= e.f)   continue;
        int v = e.to;
        if (dist[v] == dist[u] + 1) {
            int df = dinitz_dfs(v, min(f, e.cap - e.f));
            if (df > 0) {
                e.f += df;
                graph[v][e.rev].f -= df;
                return df;
            }
        }
    }
    return 0;
}

int maxFlow() {
    int result = 0;
    while (dinitz_bfs()) {
        memset(work, 0, sizeof(work));
        while (int delta = dinitz_dfs(src, INT_MAX))
            result += delta;
    }
    return result;
}

ll s;
double arr1[MAXN][2], arr2[MAXN][3];

int main(int argc, char* argv[]) {
    cin >> n >> m >> s;
    FOR(i, 0, MAXN)     graph[i].clear();

    s -= 10;
    src = MAXT * 2 + 5;
    dest = MAXT * 2 + 6;

    FOR(i, 0, n)    cin >> arr1[i][0] >> arr1[i][1];
    FOR(i, 0, m)    cin >> arr2[i][0] >> arr2[i][1] >> arr2[i][2];

    FOR(i, 0, n)    addEdge(src, i, 1);
    FOR(i, 0, m)    addEdge(i+MAXT, dest, arr2[i][2]);

    FOR(i, 0, n) {
        FOR(j, 0, m) {
            if (hypot(arr1[i][0] - arr2[j][0], arr1[i][1] - arr2[j][1]) <= s) {
                addEdge(i, j+MAXT, 1);
            }
        }
    }

    if (maxFlow() == n)     cout << "YES" << endl;
    else                    cout << "NO" << endl;


    return 0;
}


